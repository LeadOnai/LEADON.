import { useEffect, useState } from 'react'

export default function ToggleTheme() {
  const [dark, setDark] = useState(false)

  useEffect(() => {
    if (dark) document.documentElement.classList.add('dark')
    else document.documentElement.classList.remove('dark')
  }, [dark])

  return (
    <button
      onClick={() => setDark(!dark)}
      className="absolute left-4 top-4 w-10 h-5 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center p-1"
    >
      <span
        className={`w-4 h-4 bg-white rounded-full transform transition-transform duration-300 ${
          dark ? 'translate-x-5' : 'translate-x-0'
        }`}
      ></span>
    </button>
  )
}
