import { useState } from 'react'

export default function MicRecorder({ onText }) {
  const [recording, setRecording] = useState(false)

  const start = () => {
    const recognition = new (window.SpeechRecognition ||
      window.webkitSpeechRecognition)()
    recognition.lang = 'es-ES'
    recognition.continuous = false
    recognition.interimResults = false
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript
      onText(transcript)
    }
    recognition.start()
    setRecording(true)
    recognition.onend = () => setRecording(false)
  }

  return (
    <button
      onClick={start}
      className={`p-3 rounded-full ${
        recording ? 'bg-red-500' : 'bg-[var(--azul)]'
      } text-white`}
    >
      🎙
    </button>
  )
}
