import ToggleTheme from '../components/ToggleTheme'

const contactos = [
  { nombre: 'Ryan Suárez', telefono: '622785612' },
  { nombre: 'Alfonso Sanz', telefono: '689327846' },
  { nombre: 'Mariela Domínguez', telefono: '668310537' },
  { nombre: 'Álvaro Vela', telefono: '699067345' }
]

export default function Contactos() {
  return (
    <div className="relative min-h-screen p-6">
      <ToggleTheme />
      <h1 className="text-3xl font-bold mb-4">Contactos</h1>
      <input
        placeholder="Buscar"
        className="border rounded-full px-4 py-2 w-full mb-4 dark:bg-gray-800"
      />
      {contactos.map((c, i) => (
        <div key={i} className="flex items-center justify-between py-2 border-b">
          <div>
            <p>{c.nombre}</p>
            <span className="text-sm text-gray-500">+34 {c.telefono}</span>
          </div>
        </div>
      ))}
      <button className="fixed bottom-6 right-6 bg-[var(--azul)] text-white rounded-full w-12 h-12 text-2xl shadow-lg">
        +
      </button>
    </div>
  )
}
