import ToggleTheme from '../components/ToggleTheme'
import MicRecorder from '../components/MicRecorder'
import { useState } from 'react'

export default function Home() {
  const [notes, setNotes] = useState([])

  const handleVoice = (text) => {
    setNotes((prev) => [...prev, text])
  }

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen overflow-hidden p-6">
      <ToggleTheme />
      <h1 className="text-5xl font-bold text-[var(--azul)] text-center leading-tight">
        ¿De quién quieres hablar hoy?
      </h1>
      <div className="mt-10 flex items-center gap-3">
        <input
          className="border border-gray-300 rounded-full px-4 py-2 w-60 dark:bg-gray-800"
          placeholder="Pregunta lo que quieras"
        />
        <MicRecorder onText={handleVoice} />
      </div>
      <div className="mt-10 w-80 text-sm">
        {notes.map((n, i) => (
          <p key={i} className="mb-2 border-b border-gray-200 pb-1">
            {n}
          </p>
        ))}
      </div>
    </div>
  )
}
